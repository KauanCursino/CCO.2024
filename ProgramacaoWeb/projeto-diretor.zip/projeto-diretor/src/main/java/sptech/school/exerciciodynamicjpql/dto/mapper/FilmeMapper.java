package sptech.school.exerciciodynamicjpql.dto.mapper;

import sptech.school.exerciciodynamicjpql.dto.FilmeCriacaoDto;
import sptech.school.exerciciodynamicjpql.entity.Filme;

public class FilmeMapper {

    public Filme toEntity(FilmeCriacaoDto dto){
        Filme filme = new Filme();

        filme.setTitulo(dto.getTitulo());
        filme.setSinopse(dto.getSinopse());
        filme.setGenero(dto.getGenero());
        filme.setAnoLancamento(dto.getAnoLancamento());
       // filme.setDiretor(dto.getDiretorId());

        return filme;

    }
}

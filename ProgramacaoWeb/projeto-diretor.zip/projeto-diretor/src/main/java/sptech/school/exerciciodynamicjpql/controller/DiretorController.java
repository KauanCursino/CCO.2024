package sptech.school.exerciciodynamicjpql.controller;


import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sptech.school.exerciciodynamicjpql.dto.DiretorConsultaDto;
import sptech.school.exerciciodynamicjpql.dto.mapper.DiretorMapper;
import sptech.school.exerciciodynamicjpql.entity.Diretor;
import sptech.school.exerciciodynamicjpql.repository.DiretorRepository;

@RestController
@RequestMapping("/diretores")
public class DiretorController {
    @Autowired
    private DiretorRepository diretorRepository;

    @PostMapping
    public ResponseEntity<DiretorConsultaDto> criarDiretor(@RequestBody @Valid Diretor diretor) {

        Diretor diretorSalva = diretorRepository.save(diretor);

        DiretorConsultaDto dto = DiretorMapper.toDto(diretorSalva);
        return ResponseEntity.ok(dto);
    }

}

package sptech.school.exerciciodynamicjpql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioDynamicJpqlApplication {
    public static void main(String[] args) {
        SpringApplication.run(ExercicioDynamicJpqlApplication.class, args);
    }
}

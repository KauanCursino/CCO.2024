package sptech.school.exerciciodynamicjpql.dto;

import jakarta.validation.constraints.*;

import java.time.LocalDate;

public class DiretorConsultaDto {

    private Integer id;

    @NotBlank
    @NotEmpty
    @Size(min = 3)
    private String nome;

    @NotBlank
    private String nacionalidade;

    @NotNull
    @Past
    private LocalDate dataNascimento;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNacionalidade() {
        return nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
}
package sptech.school.exerciciodynamicjpql.dto;

import org.springframework.cglib.core.Local;
import sptech.school.exerciciodynamicjpql.entity.Diretor;

import java.time.LocalDate;

public class FilmeListagemDto {

    private String titulo;
    private String sinopse;
    private LocalDate anoLancamento;
    private Diretor diretor;


}

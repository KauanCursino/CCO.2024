package sptech.school.exerciciodynamicjpql.dto.mapper;

import sptech.school.exerciciodynamicjpql.dto.DiretorConsultaDto;
import sptech.school.exerciciodynamicjpql.dto.DiretorCriacaoDto;
import sptech.school.exerciciodynamicjpql.entity.Diretor;

public class DiretorMapper {

    public Diretor toEntity(DiretorCriacaoDto dto){
        Diretor diretor = new Diretor();

        diretor.setNome(dto.getNome());
        diretor.setNacionalidade(dto.getNascionalidade());
        diretor.setDataNascimento(dto.getDataNascimento());

        return diretor;
    }

    public static DiretorConsultaDto toDto(Diretor diretor){
        DiretorConsultaDto dto = new DiretorConsultaDto();

        dto.setNome(diretor.getNome());
        dto.setNacionalidade(diretor.getNacionalidade());
        dto.setDataNascimento(diretor.getDataNascimento());

        return dto;
    }
}

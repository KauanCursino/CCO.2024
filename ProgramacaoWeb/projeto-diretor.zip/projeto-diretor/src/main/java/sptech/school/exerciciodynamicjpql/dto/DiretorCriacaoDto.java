package sptech.school.exerciciodynamicjpql.dto;

import jakarta.validation.constraints.*;

import java.time.LocalDate;

public class DiretorCriacaoDto  {

    @NotBlank
    @NotEmpty
    @Size(min = 3)
    private String nome;

    @NotBlank
    @NotEmpty
    private String nascionalidade;

    @NotNull
    @Past
    private LocalDate dataNascimento;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNascionalidade() {
        return nascionalidade;
    }

    public void setNascionalidade(String nascionalidade) {
        this.nascionalidade = nascionalidade;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
}

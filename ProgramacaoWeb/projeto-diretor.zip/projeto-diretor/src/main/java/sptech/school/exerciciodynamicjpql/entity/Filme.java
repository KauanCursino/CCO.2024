package sptech.school.exerciciodynamicjpql.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Getter
@Setter
public class Filme {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String titulo;
    private String genero;
    private LocalDate anoLancamento;
    private String sinopse;

    @ManyToOne
    private Diretor diretor;

}

package sptech.school.exerciciodynamicjpql.dto;

import jakarta.validation.constraints.*;

import java.time.LocalDate;

public class FilmeCriacaoDto {

    @NotBlank
    @NotEmpty

    private String titulo;

    @NotBlank
    @NotEmpty
    @Size(min = 3)
    private String genero;

    @NotNull
    @Past
    private LocalDate anoLancamento;

    private String sinopse;

    private Integer diretorId;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public LocalDate getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(LocalDate anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

    public String getSinopse() {
        return sinopse;
    }

    public void setSinopse(String sinopse) {
        this.sinopse = sinopse;
    }

    public Integer getDiretorId() {
        return diretorId;
    }

    public void setDiretorId(Integer diretorId) {
        this.diretorId = diretorId;
    }
}

package sptech.school.exerciciodynamicjpql.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.school.exerciciodynamicjpql.entity.Filme;

@RestController
@RequestMapping("/filmes")
public class FilmeController {

    @PostMapping
    public ResponseEntity<Filme> addFilme(@RequestBody Filme filme) {
        return null;
    }
}


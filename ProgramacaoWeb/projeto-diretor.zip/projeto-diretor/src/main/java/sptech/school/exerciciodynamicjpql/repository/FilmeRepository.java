package sptech.school.exerciciodynamicjpql.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import sptech.school.exerciciodynamicjpql.entity.Diretor;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface FilmeRepository extends JpaRepository<Diretor, Integer> {

    List<Diretor> findByTituloContainsIgnoreCase(String titulo);

    List<Diretor> findByDataLancamentoBetween(LocalDate dataInicio, LocalDate dataFim);

    @Query("SELECT f FROM Diretor f ORDER BY f.custoProducao DESC LIMIT 1")
    Optional<Diretor> findTopByCustoProducaoDesc();
}
package school.sptech;

public interface iAtendimento {

    public void realizarAtendimento();

}
